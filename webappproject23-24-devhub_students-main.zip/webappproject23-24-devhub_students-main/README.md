[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/-yaTGY9V)
[![Open in Codespaces](https://classroom.github.com/assets/launch-codespace-7f7980b617ed060a017424585567c406b6ee15c891e84e1186181d67ecf80aa0.svg)](https://classroom.github.com/open-in-codespaces?assignment_repo_id=13138049)
# WebAppProjectTemplate
#Siehe bitte ProjektFinal/READ ME.pdf ( https://github.com/Web-based-Application-Systems-FRA-UAS/webappproject23-24-devhub_students/blob/8b5bfbfe2ea7e0b0311d6014988acab92901da55/ProjektFinal/READ%20ME.pdf )
