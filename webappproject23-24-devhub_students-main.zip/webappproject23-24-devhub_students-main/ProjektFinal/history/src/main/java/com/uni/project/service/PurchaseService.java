package com.uni.project.service;

import com.uni.project.model.CustomerEntity;
import com.uni.project.model.PurchaseEntity;
import com.uni.project.repository.CustomerRepository;
import com.uni.project.repository.PurchaseRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.NoSuchElementException;

//Service class for managing purchase-related operations
@Service
public class PurchaseService {

	@Autowired
	private PurchaseRepository purchaseRepository;

	@Autowired
	private CustomerRepository customerRepository;

	// Method to retrieve purchase history for a specific customer
	public List<PurchaseEntity> getPurchaseHistory(String username) {
		// Retrieve the customer based on the provided username
		CustomerEntity customer = customerRepository.findByUsername(username)
				.orElseThrow(() -> new NoSuchElementException("User not found with username: " + username));
		// Use the purchaseRepository to fetch the purchase history for the customer
		List<PurchaseEntity> purchaseHistory = purchaseRepository.findByCustomer(customer);
		return purchaseHistory;
	}

	// Method to retrieve purchase history for all customers
	public List<PurchaseEntity> getAllPurchaseHistory() {
		// Use the purchaseRepository to fetch the purchase history for all customers
		List<PurchaseEntity> purchaseHistory = purchaseRepository.findAll();

		return purchaseHistory;
	}
	
	// Method to delete a purchase by its ID
	public String deletePurchase(long id) {
		// Use the purchaseRepository to fetch the purchase history for all customers
		purchaseRepository.deleteById(id);
		return "Deleted successfully";
	}
}
