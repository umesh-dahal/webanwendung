package com.uni.project.repository;


import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.uni.project.model.CustomerEntity;

//Repository interface for managing CustomerEntity objects
@Repository
public interface CustomerRepository extends JpaRepository<CustomerEntity, Long>{
	
	// Custom query to find a customer by username and password
	 @Query("SELECT c FROM CustomerEntity c WHERE c.username = :username AND c.password = :password")
	    Optional<CustomerEntity> findByUsernameAndPassword(@Param("username") String username, @Param("password") String password);
	 	
	 	// Find a customer by username
	 	Optional<CustomerEntity> findByUsername(String username);
}
