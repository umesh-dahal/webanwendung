package com.uni.project.model;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity // Marks this class as a JPA entity
public class CustomerEntity {
	@Id // Specifies the primary key of the entity
	@GeneratedValue(strategy = GenerationType.IDENTITY) // Specifies auto-generation of the ID
	private Long id; // Represents the ID of the customer entity
    private String username; // Represents the username of the customer
    private String password; // Represents the password of the customer
    private String passwordRepeat; // Represents the repeated password of the customer
    
    // Getter and setter for 'id'
	public Long getId() {
		return id;
	}

	// Getter and setter for 'passwordRepeat'
	public String getPasswordRepeat() {
		return passwordRepeat;
	}
	public void setPasswordRepeat(String passwordRepeat) {
		this.passwordRepeat = passwordRepeat;
	}
	// Default constructor
	public CustomerEntity() {
	
	}
	// Getter and setter for 'username'
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	// Getter and setter for 'password'
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
    
    
}
