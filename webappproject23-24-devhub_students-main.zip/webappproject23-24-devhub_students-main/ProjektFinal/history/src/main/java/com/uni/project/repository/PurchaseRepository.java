package com.uni.project.repository;

import com.uni.project.model.CustomerEntity;
import com.uni.project.model.PackageEntity;
import com.uni.project.model.PurchaseEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;
import java.util.Optional;

//Repository interface for managing PurchaseEntity objects
public interface PurchaseRepository extends JpaRepository<PurchaseEntity, Long> {
	
	// Find a purchase entity by customer and package entity
	Optional<PurchaseEntity> findByCustomerAndPackageEntity(CustomerEntity customer, PackageEntity packageEntity);

	// Find a list of purchase entities by customer
	List<PurchaseEntity> findByCustomer(CustomerEntity customer);

	// Custom query to check if a purchase exists for a specific customer and package entity
	@Query("SELECT COUNT(p) > 0 FROM PurchaseEntity p WHERE p.customer = :customer AND p.packageEntity = :packageEntity")
	boolean existsByCustomerAndPackageEntity(@Param("customer") CustomerEntity customer,
			@Param("packageEntity") PackageEntity packageEntity);
}
