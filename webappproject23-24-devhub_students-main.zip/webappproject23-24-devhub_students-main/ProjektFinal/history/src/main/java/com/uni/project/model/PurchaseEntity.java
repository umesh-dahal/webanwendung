package com.uni.project.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity // Marks this class as a JPA entity
public class PurchaseEntity {

	@Id // Specifies the primary key of the entity
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne // Defines a many-to-one relationship between entities
	private CustomerEntity customer;

	@ManyToOne // Defines a many-to-one relationship between entities
	private PackageEntity packageEntity;

	// Represents the date and time when the purchase was made
	private LocalDateTime purchaseDate;

	// Getter and setter for 'id'
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	// Getter and setter for 'customer'
	public CustomerEntity getCustomer() {
		return customer;
	}

	public void setCustomer(CustomerEntity customer) {
		this.customer = customer;
	}

	// Getter and setter for 'packageEntity'
	public PackageEntity getPackageEntity() {
		return packageEntity;
	}

	public void setPackageEntity(PackageEntity packageEntity) {
		this.packageEntity = packageEntity;
	}

	// Getter and setter for 'purchaseDate'
	public LocalDateTime getPurchaseDate() {
		return purchaseDate;
	}

	public void setPurchaseDate(LocalDateTime purchaseDate) {
		this.purchaseDate = purchaseDate;
	}

}