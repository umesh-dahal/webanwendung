package com.uni.project.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.uni.project.model.PurchaseEntity;
import com.uni.project.service.PurchaseService;

//Controller class for handling purchase history related endpoints
@CrossOrigin(origins = { "http://localhost:8080", "http://localhost:2020" })
@RestController
@RequestMapping("/history")
public class HistoryController {

	@GetMapping("/test")
	public String getAllHistories() {
		return "test";
	}

	@Autowired
	private PurchaseService purchaseService;

	// Retrieves and returns purchase history for a specific user
	@GetMapping("/purchase-history/{username}")
	public List<PurchaseEntity> getPurchaseHistory(@PathVariable String username) {
		try {
			// Retrieve and return the purchase history for the customer
			List<PurchaseEntity> purchaseHistory = purchaseService.getPurchaseHistory(username);
			return purchaseHistory;
		} catch (Exception e) {
			throw e; // Re-throw the exception to let it propagate to the global exception handler
		}
	}

	// Retrieves and returns purchase history for all users
	@GetMapping("/purchase-historyforall")
	public List<PurchaseEntity> getAllPurchaseHistory() {
		try {
			// Retrieve and return the purchase history for all customers
			List<PurchaseEntity> purchaseHistory = purchaseService.getAllPurchaseHistory();

			return purchaseHistory;
		} catch (Exception e) {
			throw e; // Re-throw the exception to let it propagate to the global exception handler

		}
	}

	// Deletes a purchase by its ID
	@DeleteMapping("/deletePurchase/{id}")
	public String deletePurchase(@PathVariable long id) {
		try {
			// Delete the purchase by its ID
			String purchaseHistory = purchaseService.deletePurchase(id);

			return purchaseHistory;
		} catch (Exception e) {
			throw e; // Re-throw the exception to let it propagate to the global exception handler

		}
	}
}