package com.mp.service;

import java.nio.charset.StandardCharsets;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mp.model.PackageEntity;

//Component responsible for making RESTful service calls related to packages
@Component
public class PackageServiceCall {

	private static final Logger logger = LoggerFactory.getLogger(PackageServiceCall.class);
	String packageServiceUrl = "http://localhost:6060/package"; // URL of the package service

	@Autowired
	private RestTemplate restTemplate; // RestTemplate for making HTTP requests

	// Method to delete a package by its ID
	public String deletePackageId(long id) {
		String deleteUrl = packageServiceUrl + "/" + id;
		logger.info("Sending DELETE request to {}", deleteUrl);
		restTemplate.getMessageConverters().add(0, new StringHttpMessageConverter(StandardCharsets.UTF_8));
		ResponseEntity<String> response = restTemplate.exchange(deleteUrl, HttpMethod.DELETE, null, String.class);
		logger.info("Got DELETE response: {}", response.getBody());
		return response.getBody();
	}

	// Method to retrieve a package by its ID
	public PackageEntity getPackageId(long id) {
		String deleteUrl = packageServiceUrl + "/" + id;
		logger.info("Sending GET package by Id, request to {}", deleteUrl);
		restTemplate.getMessageConverters().add(0, new StringHttpMessageConverter(StandardCharsets.UTF_8));
		ResponseEntity<String> response = restTemplate.exchange(deleteUrl, HttpMethod.GET, null, String.class);

		if (response.getStatusCode() == HttpStatus.OK) {
			logger.info("Successfully received response from Package Service");
			return convertStringToObject(response.getBody());
		} else {
			logger.error("Failed to get reservations from Package Service, status code: {}", response.getStatusCode());
			throw new RuntimeException("Failed to get reservations from Package Service");
		}
	}

	// Method to retrieve all packages
	public List<PackageEntity> getAllPackages() {
		String deleteUrl = packageServiceUrl;
		logger.info("Sending GET All packages, request to {}", deleteUrl);

		ResponseEntity<String> response = restTemplate.exchange(deleteUrl, HttpMethod.GET, null, String.class);

		if (response.getStatusCode() == HttpStatus.OK) {
			logger.info("Successfully received response from Package Service : " + response.getBody());
			return convertStringToList(response.getBody());
		} else {
			logger.error("Failed to get reservations from Package Service, status code: {}", response.getStatusCode());
			throw new RuntimeException("Failed to get reservations from Package Service");
		}
	}

	// Method to add a new package
	public PackageEntity addPackages(PackageEntity data) {
		ResponseEntity<String> response = null;
		try {
			String deleteUrl = packageServiceUrl;
			logger.info("Add package API, POST request to {}", deleteUrl);
			HttpHeaders httpHeaders = new HttpHeaders();
			httpHeaders.setContentType(MediaType.APPLICATION_JSON);
			ObjectMapper mapper = new ObjectMapper();
			String body;

			body = mapper.writeValueAsString(data);

			HttpEntity<String> entity = new HttpEntity(body, httpHeaders);
			restTemplate.getMessageConverters().add(0, new StringHttpMessageConverter(StandardCharsets.UTF_8));
			response = restTemplate.exchange(deleteUrl, HttpMethod.POST, entity, String.class);
			return convertStringToObject(response.getBody());
		} catch (Exception e) {
			return null;
		}
	}

	// Method to convert JSON string to a list of PackageEntity objects
	private List<PackageEntity> convertStringToList(String data) {
		try {
			ObjectMapper mapper = new ObjectMapper();
			List<PackageEntity> link = mapper.readValue(data, new TypeReference<List<PackageEntity>>() {
			});
			return link;
		} catch (Exception e) {
			return null;
		}
	}

	// Method to convert JSON string to a PackageEntity object
	private PackageEntity convertStringToObject(String data) {
		try {
			ObjectMapper mapper = new ObjectMapper();
			PackageEntity link = mapper.readValue(data, PackageEntity.class);
			return link;
		} catch (Exception e) {
			return null;
		}
	}
}
