package com.mp.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class Homepage {

	// Controller for mapping the homepage endpoint
	@GetMapping("/")
	public String getHomepage() {
		return "homepage";
	}
}
