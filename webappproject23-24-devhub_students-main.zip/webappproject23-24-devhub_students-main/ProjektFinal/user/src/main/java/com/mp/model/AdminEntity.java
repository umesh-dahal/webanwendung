package com.mp.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

//Entity class representing the Admin entity in the database
@Entity
public class AdminEntity {

	@Id
	private String adminId; // Unique identifier for the admin
	private String password; // Password associated with the admin account

	// Getter method for retrieving admin ID
	public String getAdminId() {
		return adminId;
	}

	// Setter method for setting admin ID
	public void setAdminId(String adminId) {
		this.adminId = adminId;
	}

	// Getter method for retrieving admin password
	public String getPassword() {
		return password;
	}

	// Setter method for setting admin password
	public void setPassword(String password) {
		this.password = password;
	}

}
