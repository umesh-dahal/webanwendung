package com.mp.controller;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import com.mp.model.AdminEntity;
import com.mp.model.CustomerEntity;
import com.mp.model.PackageEntity;
import com.mp.model.PurchaseEntity;
import com.mp.repository.AdminRepository;
import com.mp.service.CustomerService;
import com.mp.service.PackageService;;

//Controller class for managing administrative activities.
@Controller
public class AdminController {

	@Autowired
	private CustomerService customerService;

	@Autowired
	private AdminRepository adminRepository;

	@Autowired
	private PackageService packageService;

	// Handles GET request for admin login
	@GetMapping("/admin/login")
	public String getAdminLogin(Model model) {
		// Prepare an empty AdminEntity for login form
		AdminEntity adminentity = new AdminEntity();
		model.addAttribute("admin", adminentity);
		return "admin/admin_login";
	}

	// Handles POST request for admin login
	@PostMapping("/admin/work")
	public String getadminWork(@ModelAttribute("admin") AdminEntity adminentity) {
		// Retrieve admin data from the database based on adminId
		String adminId = adminentity.getAdminId();
		Optional<AdminEntity> adminData = adminRepository.findById(adminId);

		if (adminData.isPresent()) {
			AdminEntity adminFromDB = adminData.get();
			String passwordFromDB = adminFromDB.getPassword();

			// Check if password matches
			if (adminentity.getPassword().equals(passwordFromDB)) {
				return "admin/admin_workspace"; // Redirect to admin workspace if login successful
			} else {
				return "no";
			}
		} else {
			return "no";
		}
	}

	// Handles GET request for admin workspace
	@GetMapping("admin/work")
	public String getadminWork(Model model) {
		System.out.println("--->");
		return "admin/admin_workspace";
	}

	// Handles GET request for viewing packages
	@GetMapping("admin/package")
	public String getAdminPackage(Model m) {
		List<PackageEntity> pack = packageService.getAllPackage();
		m.addAttribute("pack", pack);
		return "admin/package";
	}

	// Handles GET request for viewing packages
	@GetMapping("admin/addpackage")
	public String getPackageForm() {
		return "admin/add_package";
	}

	// Handles POST request for adding a package
	@PostMapping("admin/package/created")
	public String addPackage(@ModelAttribute PackageEntity pack) {
		packageService.addPackages(pack);
		return "redirect:http://localhost:2020/admin/package";
	}

	// Handles GET request for deleting a package
	@GetMapping("/package/delete/{id}")
	public String deletePackage(@PathVariable Long id, Model m) {
		try {
			System.out.println("===from code delete package==>" + id);
			packageService.deletePackage(id);
		} catch (Exception e) {
			String errMessage = e.getMessage();
			if (e.getMessage().contains(":")) {
				String[] split = e.getMessage().split(":");
				errMessage = split[1];
			}
			// Display error message and return to package view
			System.out.println("Error mes=" + errMessage);
			List<PackageEntity> pack = packageService.getAllPackage();
			m.addAttribute("pack", pack);
			m.addAttribute("errorMessage", errMessage);
			return "admin/package";
		}

		return "redirect:http://localhost:2020/admin/package";
	}

	// Handles GET request for editing a package
	@GetMapping("package/edit/{id}")
	public String edit(@PathVariable Long id, Model m) {
		PackageEntity pack = packageService.getProductById(id);
		m.addAttribute("pack", pack);
		return "admin/update_package";
	}

	// Handles POST request for updating a package
	@PostMapping("/package/update")
	public String updatePackage(@ModelAttribute PackageEntity pack) {
		packageService.addPackages(pack);
		return "redirect:http://localhost:2020/admin/package";
	}

	// Handles GET request for viewing reservations
	@GetMapping("admin/reservation")
	public String getAdminReservation(Model model) {

		List<PurchaseEntity> allReservations = packageService.getAllreservation();
		model.addAttribute("Reservations", allReservations);
		return "admin/reservation";
	}

	// Handles GET request for deleting a reservation
	@GetMapping("admin/reservation/delete/{id}")
	public String getAdminDeleteReservation(@PathVariable Long id, Model model) {
		packageService.deleteReservationById(id);
		// Retrieve all reservations from the database
		List<PurchaseEntity> allReservations = packageService.getAllreservation();
		model.addAttribute("Reservations", allReservations);
		return "admin/reservation";
	}

	// Handles GET request for viewing all customers
	@GetMapping("/admin/all_customers")
	public String getAllUsers(Model model) {
		List<CustomerEntity> allUsers = customerService.getAllCustomers();
		model.addAttribute("users", allUsers);
		return "admin/all_customers";
	}

	// Handles GET request for deleting a customer
	@GetMapping("/customer/delete/{username}")
	public String editCustomer(@PathVariable String username, Model m) {
		// Retrieve customer by username
		Optional<CustomerEntity> pack = customerService.getCustomerByUsername(username);
		CustomerEntity entity = pack.get();
		List<PurchaseEntity> packageList = packageService.findPackagesByCustomerEntity(entity);

		// Check if customer has reservations, if yes, display error message
		if (!packageList.isEmpty()) {
			m.addAttribute("errorMessage", "Customer already have reservations, so delete is not permitted");
			List<CustomerEntity> allUsers = customerService.getAllCustomers();
			m.addAttribute("users", allUsers);
			return "admin/all_customers";
		}

		// If no reservations, delete the customer and redirect to admin all customers
		// page
		customerService.deleteCustomer(entity);
		List<CustomerEntity> allUsers = customerService.getAllCustomers();
		m.addAttribute("users", allUsers);
		return "admin/all_customers";
	}

}
