package com.mp.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

//Entity class representing a package entity in the database
@Entity
public class PackageEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id; // Unique identifier for the package
	private String name; // Name of the package
	private String fromdate; // Start date of the package
	private String todate; // End date of the package
	private double price; // Price of the package

	// Default constructor
	public PackageEntity() {
	}

	// Parameterized constructor
	public PackageEntity(Long id, String name, String fromdate, String todate, double price) {
		this.id = id;
		this.name = name;
		this.fromdate = fromdate;
		this.todate = todate;
		this.price = price;

	}

	// Getter method for retrieving the package ID
	public Long getId() {
		return id;
	}

	// Setter method for setting the package ID
	public void setId(Long id) {
		this.id = id;
	}

	// Getter method for retrieving the package name
	public String getName() {
		return name;
	}

	// Setter method for setting the package name
	public void setName(String name) {
		this.name = name;
	}

	// Getter method for retrieving the start date of the package
	public String getFromdate() {
		return fromdate;
	}

	// Setter method for setting the start date of the package
	public void setFromdate(String fromdate) {
		this.fromdate = fromdate;
	}

	// Getter method for retrieving the end date of the package
	public String getTodate() {
		return todate;
	}

	// Setter method for setting the end date of the package
	public void setTodate(String todate) {
		this.todate = todate;
	}

	// Getter method for retrieving the price of the package
	public double getPrice() {
		return price;
	}

	// Setter method for setting the price of the package
	public void setPrice(double price) {
		this.price = price;
	}

	// Override toString method to provide a string representation of the object
	@Override
	public String toString() {
		return "PackageEntity{" + "id=" + id + ", name='" + name + '\'' + ", fromdate='" + fromdate + '\''
				+ ", todate='" + todate + '\'' + ", price=" + price + '}';
	}
}
