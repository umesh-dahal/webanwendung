package com.mp.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

//Entity class representing a customer entity in the database
@Entity
public class CustomerEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id; // Unique identifier for the customer
	private String username; // Username of the customer
	private String password; // Password of the customer
	private String passwordRepeat; // Repeated password for validation purposes

	// Default constructor
	public CustomerEntity() {

	}

	// Getter method for retrieving the customer ID
	public Long getId() {
		return id;
	}

	// Getter method for retrieving the repeated password
	public String getPasswordRepeat() {
		return passwordRepeat;
	}

	// Setter method for setting the repeated password
	public void setPasswordRepeat(String passwordRepeat) {
		this.passwordRepeat = passwordRepeat;
	}

	// Getter method for retrieving the username
	public String getUsername() {
		return username;
	}

	// Setter method for setting the username
	public void setUsername(String username) {
		this.username = username;
	}

	// Getter method for retrieving the password
	public String getPassword() {
		return password;
	}

	// Setter method for setting the password
	public void setPassword(String password) {
		this.password = password;
	}

	// Override toString method to provide a string representation of the object
	@Override
	public String toString() {
		return "CustomerEntity [id=" + id + ", username=" + username + ", password=" + password + ", passwordRepeat="
				+ passwordRepeat + "]";
	}

}
