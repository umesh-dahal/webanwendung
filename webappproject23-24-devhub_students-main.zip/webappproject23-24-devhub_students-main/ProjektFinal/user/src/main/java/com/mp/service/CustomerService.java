package com.mp.service;

import com.mp.model.CustomerEntity;
import com.mp.model.PackageEntity;
import com.mp.model.PurchaseEntity;
import com.mp.repository.CustomerRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.validation.BindingResult;
import org.springframework.web.client.RestTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.List;
import java.util.Optional;
import org.springframework.ui.Model;

//Service class for handling operations related to customers
@Service
public class CustomerService {

	private static final Logger logger = LoggerFactory.getLogger(CustomerService.class);

	@Autowired
	private CustomerRepository customerRepository;
	@Autowired
	private PackageServiceCall packageService;
	@Autowired
	private RestTemplate restTemplate;

	// Method for user registration
	public boolean registerUser(CustomerEntity customer, BindingResult result, Model model) {
		// Validate the input/Password
		if (!customer.getPassword().equals(customer.getPasswordRepeat())) {
			result.rejectValue("passwordRepeat", "error.user", "Passwords do not match");
			return false;
		}

		// Check if the username is already taken
		Optional<CustomerEntity> existingUser = customerRepository.findByUsername(customer.getUsername());
		if (existingUser.isPresent()) {
			result.rejectValue("username", "error.user", "Username already exists");
			return false; // Registration unsuccessful
		}

		// Save the user to the database
		customerRepository.save(customer);

		return true; // Registration successful
	}

	// Method to get all customers for Admin
	public List<CustomerEntity> getAllCustomers() {
		return customerRepository.findAll();
	}

	// Method to save a new customer
	public void saveCustomer(CustomerEntity customer) {
		customerRepository.save(customer);
	}

	// Method to delete a customer
	public void deleteCustomer(CustomerEntity customer) {
		customerRepository.delete(customer);
	}

	// Method to update a customer's information
	public String updateCustomer(long id, CustomerEntity customer, BindingResult result, Model model) {
		Optional<CustomerEntity> findById = customerRepository.findById(id);
		if (findById.isPresent()) {
			if (!customer.getPassword().equals(customer.getPasswordRepeat())) {
				result.rejectValue("passwordRepeat", "error.customer", "Passwords do not match");
				return "Passwords do not match"; // Return error message if passwords do not match
			}
			Optional<CustomerEntity> byUsername = customerRepository.findByUsername(customer.getUsername());
			if (byUsername != null && byUsername.isPresent() && byUsername.get().getId() != id) {
				return "Username already exists"; // Return error message if username already exists
			}
			CustomerEntity entity = findById.get();
			entity.setUsername(customer.getUsername());
			entity.setPassword(customer.getPassword());
			entity.setPasswordRepeat(customer.getPasswordRepeat());
			customerRepository.save(entity);
			return "success";
		}
		return "Updation failed";
	}

	// Method to retrieve a customer by their username
	public Optional<CustomerEntity> getCustomerByUsername(String username) {
		return customerRepository.findByUsername(username);
	}

	// Method to retrieve a customer by their ID
	public Optional<CustomerEntity> getCustomerById(long id) {
		return customerRepository.findById(id);
	} 

	// Busniess Logic for Customer Login
	public boolean handleLogin(String username, String password, Model model, HttpSession session) {
		Optional<CustomerEntity> loginData = customerRepository.findByUsernameAndPassword(username, password);

		if (loginData.isPresent()) {
			// Logic for successful login
			List<PackageEntity> pack = packageService.getAllPackages();
			model.addAttribute("pack", pack);

			// Add the customer to the model
			model.addAttribute("customer", loginData.get());

			// Store the username in the session
			session.setAttribute("username", username);

			return true; // Login successful
		} else {
			// Logic for failed login
			return false; // Login unsuccessful
		}
	}

	// Business Logic or better siad Method to send a Http Req to History
	// Application
	public List<PurchaseEntity> getHistoryResponse(String username) {
		// Make a REST request to the History Application to get purchase history
		String historyUrl = "http://localhost:1010/history/purchase-history/" + username;
		logger.info("Sending GET request to {}", historyUrl);
		ResponseEntity<List<PurchaseEntity>> historyResponse = restTemplate.exchange(historyUrl, HttpMethod.GET, null,
				new ParameterizedTypeReference<List<PurchaseEntity>>() {
				});
		logger.info("Received response with status code {}", historyResponse.getStatusCode());
		if (historyResponse.getStatusCode() == HttpStatus.OK) {
			return historyResponse.getBody();
		}

		return null;
	}

}
