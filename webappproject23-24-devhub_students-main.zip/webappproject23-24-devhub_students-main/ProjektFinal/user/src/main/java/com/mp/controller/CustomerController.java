
package com.mp.controller;

import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.mp.model.CustomerEntity;
import com.mp.model.PackageEntity;
import com.mp.model.PurchaseEntity;
import com.mp.repository.CustomerRepository;
import com.mp.service.PackageService;
import com.mp.service.CustomerService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import jakarta.servlet.http.HttpSession;

/**
 * Controller class for managing customer-related operations. Handles
 * registration, login, and purchase actions.
 */
@Controller
public class CustomerController {

	private final Logger logger = LoggerFactory.getLogger(CustomerController.class);

	@Autowired
	private PackageService packageService;
	@Autowired
	private CustomerService customerService;

	// Constructor injection of CustomerRepository
	public CustomerController(CustomerRepository customerRepository) {
	}

	// Handles GET requests for registration page
	@GetMapping("/customer/registration")
	public String getRegister(Model model) {
		model.addAttribute("user", new CustomerEntity());
		return "customer/registration"; // Return registration.html from Templates
	}

	// Handles POST requests for registration
	@PostMapping("/customer/registration")
	public String registerUser(@ModelAttribute("user") CustomerEntity customer, BindingResult result, Model model) {
		// Validate the input/Password
		boolean registrationSuccessful = customerService.registerUser(customer, result, model);

		if (registrationSuccessful) {
			model.addAttribute("registrationSuccess", true);
			return "customer/registration"; // Return registration.html from Templates
		} else {
			System.err.println("Registration failed");
			return "customer/registration"; // Return registration.html from Templates with error handling
		}
	}

	// Handles GET requests for login page
	@GetMapping("/customer/login")
	public String getLogin(Model model) {
		// Prepare an empty CustomerEntity for login form
		CustomerEntity customerentity = new CustomerEntity();
		model.addAttribute("customer", customerentity);
		return "customer/login_customer"; // Return login_customer.html from Templates
	}

	// Handles POST requests for login
	@PostMapping("/customer/login")
	public String handleLogin(@ModelAttribute("customer") CustomerEntity customerEntity, Model model,
			HttpSession session) {
		// Logic for handling login
		String username = customerEntity.getUsername();
		String password = customerEntity.getPassword();

		boolean loginSuccess = customerService.handleLogin(username, password, model, session);

		if (loginSuccess) {
			return "customer/offers";
		} else {
			model.addAttribute("loginError", "login failed");
			return "customer/login_customer";
		}
	}

	// Handles POST requests for updating customer information
	@PostMapping("/customer/update/{id}")
	public String getEdit(@PathVariable("id") long id, @ModelAttribute("customer") CustomerEntity customer,
			BindingResult result, Model model, HttpSession session) {
		// Validate the input/Password
		System.out.println("----->" + id + customer);
		String updateSuccess = customerService.updateCustomer(id, customer, result, model);

		if (updateSuccess.equals("success")) {
			model.addAttribute("updateSuccess", true);
			Optional<CustomerEntity> customerOptional = customerService.getCustomerById(id);

			if (customerOptional.isPresent()) {
				CustomerEntity data = customerOptional.get();
				session.setAttribute("username", data.getUsername());
				// Retrieve the list of available packages for the customer
				List<PackageEntity> pack = packageService.getAllPackage();
				model.addAttribute("pack", pack);

				// Add the customer object to the model
				model.addAttribute("customer", data);
			}
			return "customer/offers"; // Return registration.html from Templates
		} else {
			System.err.println("update failed");
			Optional<CustomerEntity> customerOptional = customerService.getCustomerById(id);

			if (customerOptional.isPresent()) {
				CustomerEntity data = customerOptional.get();
				System.out.println(data);
				session.setAttribute("username", data.getUsername());
				// Add the customer object to the model
				model.addAttribute("customer", data);
				model.addAttribute("errorMessage", updateSuccess);
			}
			return "customer/edit";
		}
	}

	// Handles GET requests for editing customer information
	@GetMapping("/customer/edit")
	public String getEdit(Model model, HttpSession session) {

		// Retrieve the username from the session
		String username = (String) session.getAttribute("username");

		// Retrieve the customer based on the username
		Optional<CustomerEntity> customerOptional = customerService.getCustomerByUsername(username);

		if (customerOptional.isPresent()) {
			CustomerEntity customer = customerOptional.get();

			// Add the customer object to the model
			model.addAttribute("customer", customer);
		}
		System.out.println("-------------???");
		return "customer/edit"; // return to offers.html from Templates
	}

	// Handles GET requests for displaying available offers to customers
	@GetMapping("/customer/offers")
	public String getOffers(Model model, HttpSession session) {

		// Retrieve the username from the session
		String username = (String) session.getAttribute("username");

		// Retrieve the customer based on the username
		Optional<CustomerEntity> customerOptional = customerService.getCustomerByUsername(username);

		if (customerOptional.isPresent()) {
			CustomerEntity customer = customerOptional.get();

			// Retrieve the list of available packages for the customer
			List<PackageEntity> pack = packageService.getAllPackage();
			model.addAttribute("pack", pack);

			// Add the customer object to the model
			model.addAttribute("customer", customer);
		}

		return "customer/offers"; // return to offers.html from Templates
	}

	// Handles POST requests for purchasing a package
	@PostMapping("/customer/purchase/{packageId}")
	public String purchasePackage(@PathVariable Long packageId, HttpSession session, Model model) {
		// Log the entry point
		logger.info("Purchase endpoint called for packageId: {}", packageId);

		// Retrieve the username from the session
		String username = (String) session.getAttribute("username");

		if (username != null) {
			logger.info("Username retrieved from session: {}", username);
			boolean purchaseSuccess = packageService.buyPackage(packageId, username);

			if (purchaseSuccess) {
				// Log the success
				logger.info("Purchase successful for packageId: {}", packageId);
				// Add a success attribute to the model
				model.addAttribute("purchaseSuccess", true);
			} else {
				// Log the error
				logger.error("Purchase failed for packageId: {}", packageId);
				// Add an error attribute to the model
				model.addAttribute("purchaseError", true);
			}
		} else {
			// Log if username is null
			logger.warn("Username is null");
		}

		// Redirect to the offers page
		return "customer/purchased"; // redirect to offers.html from Templates
	}

	// Handles GET requests for displaying purchase history
	@GetMapping("/customer/history")
	public String getHistory(Model model, HttpSession session) throws UnsupportedEncodingException {
		// Retrieve the username from the session
		String username = (String) session.getAttribute("username");

		if (username != null) {
			List<PurchaseEntity> historyResponse = customerService.getHistoryResponse(username);

			if (historyResponse != null) {
				model.addAttribute("Reservations", historyResponse);
				return "customer/history";
			}
		}

		// If username is not found or customer not present, redirect to the login page
		return "redirect:/customer/login";
	}
}
