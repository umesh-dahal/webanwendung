
package com.mp.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.mp.model.CustomerEntity;
import com.mp.model.PackageEntity;
import com.mp.model.PurchaseEntity;
import com.mp.repository.PurchaseRepository;

//Service class for handling operations related to packages
@Service
public class PackageService {

	private static final Logger logger = LoggerFactory.getLogger(PackageService.class);

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private PurchaseRepository purchaseRepository;

	@Autowired
	PackageServiceCall packageServiceCall;

	@Autowired
	private CustomerService customerService;

	// Method to get all packages by calling packageServiceCall.getAllPackages()
	public List<PackageEntity> getAllPackage() {
		return packageServiceCall.getAllPackages();
	}

	// Method to add a package by calling packageServiceCall.addPackages(pack)
	public PackageEntity addPackages(PackageEntity pack) {
		return packageServiceCall.addPackages(pack);
	}

	// Method to delete a package by calling packageServiceCall.deletePackageId(id)
	public String deletePackage(Long id) {
		return packageServiceCall.deletePackageId(id);
	}

	// Method to get a package by its ID by calling
	// packageServiceCall.getPackageId(id)
	public PackageEntity getProductById(Long id) {
		return packageServiceCall.getPackageId(id);
	}

	// Method to get all reservations by sending a GET request to History Service
	// via RestTemplate
	public List<PurchaseEntity> getAllreservation() {
		String historyServiceUrl = "http://localhost:1010/history/purchase-historyforall";

		logger.info("Sending GET request to {}", historyServiceUrl);

		ResponseEntity<List<PurchaseEntity>> response = restTemplate.exchange(historyServiceUrl, HttpMethod.GET, null,
				new ParameterizedTypeReference<List<PurchaseEntity>>() {
				});

		if (response.getStatusCode() == HttpStatus.OK) {
			logger.info("Successfully received response from History Service");
			return response.getBody();
		} else {
			logger.error("Failed to get reservations from History Service, status code: {}", response.getStatusCode());
			throw new RuntimeException("Failed to get reservations from History Service");
		}
	}

	// Method to delete a reservation by sending a DELETE request to History Service
	// via RestTemplate
	public String deleteReservationById(long id) {
		String historyServiceUrl = "http://localhost:1010/history/deletePurchase/" + id;

		logger.info("Sending GET request to {}", historyServiceUrl);

		ResponseEntity<String> response = restTemplate.exchange(historyServiceUrl, HttpMethod.DELETE, null,
				String.class);

		if (response.getStatusCode() == HttpStatus.OK) {
			logger.info("Successfully received response from History Service");
			return response.getBody();
		} else {
			logger.error("Failed to get reservations from History Service, status code: {}", response.getStatusCode());
			throw new RuntimeException("Failed to get reservations from History Service");
		}
	}

	// Method to retrieve purchase history for a customer from the database
	public List<PurchaseEntity> getPurchaseHistoryByCustomer(CustomerEntity customer) {
		return purchaseRepository.findByCustomer(customer);
	}

	// Method to find purchases by customer entity
	public List<PurchaseEntity> findPackagesByCustomerEntity(CustomerEntity customer) {
		return purchaseRepository.findByCustomer(customer);
	}

	// Method to find a purchase by customer and package entity
	public Optional<PurchaseEntity> findByCustomerAndPackageEntity(CustomerEntity customer,
			PackageEntity packageEntity) {
		return purchaseRepository.findByCustomerAndPackageEntity(customer, packageEntity);
	}

	// Method to handle buying a package
	public boolean buyPackage(Long packageId, String username) {
		System.out.println("Purchase endpoint called for packageId: " + packageId);
		System.out.println("Username retrieved from session: " + username);

		// Retrieve the packageEntity by packageId
		PackageEntity packageEntity = packageServiceCall.getPackageId(packageId);

		if (packageEntity != null) {
			// Check if the customer has already purchased the package
			Optional<CustomerEntity> customerEntityOptional = customerService.getCustomerByUsername(username);

			if (customerEntityOptional.isPresent()) {
				CustomerEntity customerEntity = customerEntityOptional.get();

				Optional<PurchaseEntity> existingPurchase = purchaseRepository
						.findByCustomerAndPackageEntity(customerEntity, packageEntity);

				if (existingPurchase.isPresent()) {
					// Log failure if package already bought
					System.out.println("Package already bought for packageId: " + packageId + " by user: " + username);
					return false; // Purchase unsuccessful
				}

				// Create a PurchaseEntity and save it to the database
				PurchaseEntity purchaseEntity = new PurchaseEntity();
				purchaseEntity.setCustomer(customerEntity);
				purchaseEntity.setPackageEntity(packageEntity);
				purchaseEntity.setPurchaseDate(LocalDateTime.now());
				purchaseRepository.save(purchaseEntity);

				// Log success
				System.out.println("Purchase successful for packageId: " + packageId + " by user: " + username);

				return true; // Purchase successful
			} else {
				// Log failure if customer not found
				System.out.println("Customer not found for username: " + username);
			}
		} else {
			// Log failure if package not found
			System.out.println("Package not found for packageId: " + packageId);
		}

		return false; // Purchase unsuccessful
	}

}
