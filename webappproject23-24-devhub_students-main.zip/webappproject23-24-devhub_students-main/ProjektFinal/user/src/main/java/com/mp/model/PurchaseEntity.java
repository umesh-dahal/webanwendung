package com.mp.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

//Entity class representing a purchase entity in the database
@Entity
public class PurchaseEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id; // Unique identifier for the purchase

	@ManyToOne
	private CustomerEntity customer; // Customer associated with the purchase

	@ManyToOne(cascade = { CascadeType.MERGE, CascadeType.REMOVE })
	private PackageEntity packageEntity; // Package entity associated with the purchase

	private LocalDateTime purchaseDate; // Date and time of the purchase

	// Getter method for retrieving the purchase ID
	public Long getId() {
		return id;
	}

	// Setter method for setting the purchase ID

	public void setId(Long id) {
		this.id = id;
	}

	// Getter method for retrieving the customer associated with the purchase
	public CustomerEntity getCustomer() {
		return customer;
	}

	// Setter method for setting the customer associated with the purchase
	public void setCustomer(CustomerEntity customer) {
		this.customer = customer;
	}

	// Getter method for retrieving the package entity associated with the purchase
	public PackageEntity getPackageEntity() {
		return packageEntity;
	}

	// Setter method for setting the package entity associated with the purchase
	public void setPackageEntity(PackageEntity packageEntity) {
		this.packageEntity = packageEntity;
	}

	// Getter method for retrieving the purchase date and time
	public LocalDateTime getPurchaseDate() {
		return purchaseDate;
	}

	// Setter method for setting the purchase date and time
	public void setPurchaseDate(LocalDateTime purchaseDate) {
		this.purchaseDate = purchaseDate;
	}

}
