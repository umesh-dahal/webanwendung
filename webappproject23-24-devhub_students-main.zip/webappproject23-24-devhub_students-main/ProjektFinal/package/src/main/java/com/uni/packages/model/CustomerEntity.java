package com.uni.packages.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class CustomerEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
    private String username;
    private String password;
    private String passwordRepeat;
    
	// Default constructor
	public CustomerEntity() {
	}
	
	// Getter and setter methods for 'id'
	public Long getId() {
		return id;
	}

	// Getter and setter methods for 'passwordRepeat'
	public String getPasswordRepeat() {
		return passwordRepeat;
	}
	public void setPasswordRepeat(String passwordRepeat) {
		this.passwordRepeat = passwordRepeat;
	}
	
	// Getter and setter methods for 'username'
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	
	// Getter and setter methods for 'password'
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}

	// Override toString() method for better representation of CustomerEntity
	@Override
	public String toString() {
		return "CustomerEntity [id=" + id + ", username=" + username + ", password=" + password + ", passwordRepeat="
				+ passwordRepeat + "]";
	}
	
    
    
}
