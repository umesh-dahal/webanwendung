package com.uni.packages.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class AdminEntity {
	
	
	@Id
	private String adminId;
	private String password;
	
	// Getter and setter for 'adminId'
	public String getAdminId() {
		return adminId;
	}
	public void setAdminId(String adminId) {
		this.adminId = adminId;
	}
	
	// Getter and setter for 'password'
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}

}
