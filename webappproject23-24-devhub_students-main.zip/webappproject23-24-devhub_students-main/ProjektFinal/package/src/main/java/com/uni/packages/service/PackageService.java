package com.uni.packages.service;

import java.util.List;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.uni.packages.model.PackageEntity;
import com.uni.packages.model.PurchaseEntity;
import com.uni.packages.repository.PackageRepository;
import com.uni.packages.repository.PurchaseRepository;

@Service
public class PackageService {

	private static final Logger logger = LoggerFactory.getLogger(PackageService.class);

	@Autowired
	private PackageRepository packageRepository;

	@Autowired
	private PurchaseRepository purchaseRepository;

	// Retrieve all packages
	public List<PackageEntity> getAllPackage() {
		return packageRepository.findAll();
	}

	// Add a new package
	public PackageEntity addPackages(PackageEntity pack) {
		return packageRepository.save(pack);
	}

	// Delete a package by ID
	public void deletePackage(Long id) {
		PurchaseEntity purchase = purchaseRepository.findByPackageEntityId(id);
		if (purchase != null) {
			throw new RuntimeException(
					"Already this package is purchased by some customer, so delete is not permitted");
		}
		packageRepository.deleteById(id);
	}

	// Retrieve a package by ID
	public PackageEntity getProductById(Long id) {
		Optional<PackageEntity> pack = packageRepository.findById(id);
		if (pack.isPresent()) {
			return pack.get();
		}
		return null;
	}

}
