package com.uni.packages.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.uni.packages.model.PackageEntity;

@Repository
public interface PackageRepository extends JpaRepository<PackageEntity, Long> {

}
