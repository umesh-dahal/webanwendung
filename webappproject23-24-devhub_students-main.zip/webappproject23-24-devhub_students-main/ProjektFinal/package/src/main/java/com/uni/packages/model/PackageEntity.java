package com.uni.packages.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class PackageEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String name;
	private String fromdate;
	private String todate;
	private double price;

	// Default constructor
	public PackageEntity() {
	}

	// Parameterized constructor
	public PackageEntity(Long id, String name, String fromdate, String todate, double price) {
		this.id = id;
		this.name = name;
		this.fromdate = fromdate;
		this.todate = todate;
		this.price = price;

	}
	
	// Getter and setter methods for 'id'
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	// Getter and setter methods for 'name'
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	// Getter and setter methods for 'fromdate'
	public String getFromdate() {
		return fromdate;
	}

	public void setFromdate(String fromdate) {
		this.fromdate = fromdate;
	}

	public String getTodate() {
		return todate;
	}

	public void setTodate(String todate) {
		this.todate = todate;
	}

	// Getter and setter methods for 'price'
	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	// Override toString() method for better representation of PackageEntity
	@Override
	public String toString() {
		return "PackageEntity{" + "id=" + id + ", name='" + name + '\'' + ", fromdate='" + fromdate + '\''
				+ ", todate='" + todate + '\'' + ", price=" + price + '}';
	}
}
