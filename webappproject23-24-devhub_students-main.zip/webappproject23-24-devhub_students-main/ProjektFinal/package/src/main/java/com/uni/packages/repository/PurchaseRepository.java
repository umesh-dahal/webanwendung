package com.uni.packages.repository;

import java.util.List;
import java.util.Optional; // Import the Optional class

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.uni.packages.model.CustomerEntity;
import com.uni.packages.model.PackageEntity;
import com.uni.packages.model.PurchaseEntity;

@Repository
public interface PurchaseRepository extends JpaRepository<PurchaseEntity, Long> {
	// Find a purchase entity by customer and package entity
	Optional<PurchaseEntity> findByCustomerAndPackageEntity(CustomerEntity customer, PackageEntity packageEntity);

	// Find purchase entities by customer
	List<PurchaseEntity> findByCustomer(CustomerEntity customer);

	// Find a purchase entity by package entity ID
	PurchaseEntity findByPackageEntityId(Long id);

	// Custom query to check if a purchase exists for a specific customer and
	// package entity
	@Query("SELECT COUNT(p) > 0 FROM PurchaseEntity p WHERE p.customer = :customer AND p.packageEntity = :packageEntity")
	boolean existsByCustomerAndPackageEntity(@Param("customer") CustomerEntity customer,
			@Param("packageEntity") PackageEntity packageEntity);
}
